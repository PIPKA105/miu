# FreeVPN

Final FreeVPN project with UI, WireGuard skeleton and GitHub Actions.

## What is included
- UI with logo, server selector, status and Connect button
- WireGuardController.kt: skeleton integration using WireGuard Android backend
- sample WireGuard config in res/raw/sample_wg_conf
- servers list in res/raw/servers.json
- GitHub Action (build) included: .github/workflows/android-build.yml

## How to build locally
1. Open the project in Android Studio.
2. Wait for Gradle sync.
3. Build > Build APK(s) or Run on device.

## How to get APK automatically on GitHub
1. Create a repository `FreeVPN` under your account: https://github.com/PIPKA105
2. Upload the contents of this project (extract ZIP and push) to the repo.
3. The workflow `.github/workflows/android-build.yml` will run and produce an artifact.

## To publish an APK in Releases automatically
Add a workflow step to create a release and upload the artifact. Example (use GitHub Actions `actions/upload-release-asset` for release uploads).

## Notes
- The WireGuard dependency version may need to be updated. The project contains a skeleton WireGuard integration — you must provide real server keys and endpoints and ensure license compliance.
- For production, create a proper keystore and configure signingConfigs in `app/build.gradle`.

