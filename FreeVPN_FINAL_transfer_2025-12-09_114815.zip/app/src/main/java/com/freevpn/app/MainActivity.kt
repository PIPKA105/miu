package com.freevpn.app

import android.net.VpnService
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var wg: WireGuardController
    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            connectWithConfig()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        wg = WireGuardController(this)

        val status = findViewById<TextView>(R.id.status_text)
        val connectBtn = findViewById<Button>(R.id.connect_btn)
        val spinner = findViewById<Spinner>(R.id.server_list)

        val servers = listOf("Germany", "USA", "Netherlands", "France", "Singapore")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, servers)

        connectBtn.setOnClickListener {
            if (wg.isActive()) {
                wg.stop()
                status.text = "Status: Disconnected"
                connectBtn.text = "Connect"
            } else {
                // Request VPN permission if needed
                val intent = VpnService.prepare(this)
                if (intent != null) vpnPermission.launch(intent) else connectWithConfig()
                status.text = "Connecting..."
            }
        }
    }

    private fun connectWithConfig() {
        // For demo: load sample config from raw resource
        val cfg = resources.openRawResource(R.raw.sample_wg_conf).bufferedReader().use { it.readText() }
        val success = wg.start(cfg)
        val status = findViewById<TextView>(R.id.status_text)
        val connectBtn = findViewById<Button>(R.id.connect_btn)
        if (success) {
            status.text = "Status: Connected"
            connectBtn.text = "Disconnect"
        } else {
            status.text = "Config error"
        }
    }
}
