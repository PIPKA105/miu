package com.freevpn.app

import android.content.Context
import com.wireguard.android.backend.Tunnel
import com.wireguard.android.backend.WgQuickBackend
import com.wireguard.config.Config

class WireGuardController(context: Context) {
    private val backend = WgQuickBackend(context)
    private var tunnel: Tunnel? = null

    fun start(configText: String): Boolean {
        return try {
            val cfg = Config.parse(configText)
            tunnel = backend.create("FreeVPN", cfg)
            backend.setState(tunnel, Tunnel.State.UP)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun stop() {
        try {
            tunnel?.let { t ->
                backend.setState(t, Tunnel.State.DOWN)
                backend.delete(t)
            }
        } catch (_: Exception) {}
    }

    fun isActive(): Boolean = tunnel?.state == Tunnel.State.UP
}
